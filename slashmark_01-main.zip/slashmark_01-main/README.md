Text Encryption Using Cryptographic Algorithms

Description: You can build a simple web application to encrypt and decrypt textual information that the user keys in. Remember that strong encryption should produce different outputs even given the same input.
